module.exports = {
    InvoiceMail: require('./Mails/Invoice.js'),
}
