// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: 'AIzaSyCUeP6LLI-sjj4uaaBAvX8cURHl4azNtYA',
    authDomain: 'milaplus-pharosit.firebaseapp.com',
    projectId: 'milaplus-pharosit',
    storageBucket: 'milaplus-pharosit.appspot.com',
    messagingSenderId: '540478084805',
    appId: '1:540478084805:web:c2b28b664c9219b16742ac',
    measurementId: 'G-5TGK4YT5HG',
}

// Initialize Firebase
export const app = initializeApp(firebaseConfig)
