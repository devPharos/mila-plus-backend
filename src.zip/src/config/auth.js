export default {
    secret: '6d71a0f83b4cefc6824ce7cfa98a5579',
    expiresIn: '30d',
};
